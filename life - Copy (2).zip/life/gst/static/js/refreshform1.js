$(document).ready(function(){  
$("#submit").click(function(){
var name = $("#name").val();
var Phone = $("#Phone").val();
var Phone2 = $("#Phone2").val();
var Address1 = $("#Address").val();
var Landline1 = $("#Landline").val();
var Email1 = $("#Email").val();

if(name ==''){
alert("Insertion Failed Some Fields are Blank....!!");   	
}
else{
// Returns successful data submission message when the entered information is stored in database.
$.post("savaexec1.php",{ name1: name ,Phone1: Phone,Phone2:Phone2,Address1:Address1,Landline1:Landline1,Email1:Email1},
			function(data) {
			alert(data);
			$('#form')[0].reset(); //To reset form fields
			});
    
    }
});
});

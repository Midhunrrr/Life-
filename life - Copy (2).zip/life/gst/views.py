from django.shortcuts import render, redirect
from django.contrib.auth import login,logout,authenticate
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt
from gst.models import *
from choose import today
from life.settings import *
import datetime


@csrf_exempt
def index(request):
    if request.method=='POST':
        username=request.POST['admin']
        password=request.POST['pwd']
        user=authenticate(request,username=username,password=password)
        if user is not None:
            login(request,user)
            return redirect('/dash_board')
            # return render(request,'dash_board.html')
        else:
            return render(request, 'index.html', {'error': 'User name or Password is Wrong'})

            # return redirect('/',{'error':'User name or Password is Wrong'})
    return render(request, 'index.html',)


@login_required
@csrf_exempt
def signout(request):
    logout(request)
    return redirect('/')

@login_required
@csrf_exempt
def dash_board(request):
    x = stock_data.objects.all()
    y=sale_detaile.objects.all()
    emp=employee_detaile.objects.all()
    emp_len=len(emp)
    deal=database.objects.all()
    deal_len=len(deal)
    purch=purchase.objects.all()
    purch_len=len(purch)
    sale=sale_detaile.objects.all()
    sale_len=len(sale)
    return render(request, 'dash_board.html',{'x':x,'emp_len':emp_len,'deal_len':deal_len,'purch_len':purch_len,
                                              'sale_len':sale_len,'b':y})

@login_required
@csrf_exempt
def add(request):
    y=sale_detaile.objects.all()
    z=len(y)+1
    c = datetime.datetime.now()
    b = (c.strftime('%d%m%y/00{}').format(z))
    e = (c.strftime('%Y/%m/%d %I:%M:%S'))
    cust=customer_master.objects.all()
    sto=stock_data.objects.all()

    data_get = {key: request.POST[key] for key in request.POST}
    if request.method == 'POST':
        order_no = request.POST['Salesid']
        customer_name = request.POST['Customername']
        invoice_date = request.POST['Date']
        place_of_supply = request.POST['place']
        mode_of_transport = request.POST['mode']
        purchase_order_no = request.POST['PONo']
        purchase_order_date = request.POST['PODate']
        courier_charge = request.POST['Courier']
        prodect = request.POST['Type1']
        Quantity = request.POST['Bags1']
        paid=0
        time=e

        chec = stock_data.objects.filter(item_name__exact=prodect).get()
        chec1=chec.Quantity
        pcheck=purchase.objects.all()
        pc=[]
        for i in pcheck:
            pc.append(i.item)


        if ((int(Quantity)<=int(chec1)) & (prodect in pc)):

            a1 = prodect

            try:
                a1=prodect
                s1 = database.objects.filter(Item_name__exact=a1).get()
                ss1=s1.Sale_rate
                ss2=s1.tax
                a2=Quantity
                a3=courier_charge
                a4=int(ss1)*int(a2)
                a5=int(a4)+int(a3)
                chec.Quantity=int(chec1) - int(a2)
                chec.save()
                c1=(a4*int(ss2))/100
                aaa1=int(c1)+a5


            except database.DoesNotExist :
                pass


            amount=a4
            total=aaa1
            balance=total-paid
            # cgst=c1

            ab1=customer_name
            a7=customer_master.objects.all()
            a6 = customer_master.objects.filter(customer_name__exact=ab1).get()
            # a6.balance = int(paid) - int(a6.total)

            cuss=[]
            for i in a7:
                cuss.append(i.customer_name)

            if (ab1 in cuss):
                a6 = customer_master.objects.filter(customer_name__exact=ab1).get()
                a8=a6.IGST
                if (a8=='ACTIVE') or (a8=='Active') :
                    c2=int(c1)/2
                    cgst=c2
                    sgst=c2
                else:
                    cgst=c1
                    sgst=0



            a=sale_detaile(order_no=order_no,
                           customer_name=customer_name,
                           invoice_date=invoice_date,
                           place_of_supply=place_of_supply,
                           mode_of_transport=mode_of_transport,
                           purchase_order_no=purchase_order_no,
                           purchase_order_date=purchase_order_date,
                           courier_charge=courier_charge,
                           prodect=prodect,
                           Quantity=Quantity,
                           amount=amount,
                           time=time,
                           total=total,
                           paid=paid,
                           balance=balance,
                           cgst=cgst,
                           sgst=sgst
                           )
            a.save()
            return redirect('/add',{'x':today,'b':b})

            # return render(request, 'add.html',{'x':today,'b':b})
        else:
            mgs='Stock Quantity is low please check Stock detailes...!!!'
            return render(request, 'add.html', {'x': today, 'b': b, 'cus': cust, 'sto': sto,'msg':mgs })

    return render(request, 'add.html',{'x':today,'b':b,'cus':cust,'sto':sto,})


@login_required
@csrf_exempt
def editsales(request, id):
    x = sale_detaile.objects.get(id=id)
    y=x.prodect
    s1 = database.objects.filter(Item_name__exact=y).get()
    ss1 = s1.Sale_rate
    # print(ss1)

    return render(request, 'editsales.html', {'x': x, 'data':ss1})


@login_required
@csrf_exempt
def update_sales(request, id):
    if request.method == 'POST':
        x = sale_detaile.objects.get(id=id)

        x.order_no = request.POST['Salesid']
        x.customer_name = request.POST['Customername']
        x.invoice_date = request.POST['Date']
        x.place_of_supply = request.POST['Place']
        x.mode_of_transport = request.POST['Mode']
        x.purchase_order_no = request.POST['PONo']
        x.purchase_order_date = request.POST['PODate']
        x.courier_charge = request.POST['Amount3']
        x.prodect = request.POST['Type1[]']
        x.amount = request.POST['Amount1[]']
        x.Quantity = request.POST['Bags1[]']
        xxx=database.objects.filter(Item_name__exact=x.prodect).get()
        xxx.Sale_rate=x.amount
        xxx.save()
        xx=int(x.Quantity)*int(x.amount)
        x.amount=xx

        x.save()

        return redirect('/view_sales')

    return redirect('/view_sales')


@login_required
@csrf_exempt
def delete_sales(request, id):
    x = sale_detaile.objects.get(id=id)
    x.delete()
    return redirect('/view_sales')

@login_required
@csrf_exempt
def old_stock(request):
    data_get = {key: request.POST[key] for key in request.POST}
    if request.method == 'POST':
        try:
            item = request.POST['Varietyname']
            item1 = stock_data.objects.filter(item_name__exact=item).get()
            if item1 is not None:
                counts = request.POST['count']
                xxx = stock_data.objects.filter(item_name__exact=item).get()
                xxx.Quantity=int(xxx.Quantity)+int(counts)
                xxx.save()
                return render(request, 'old_stock.html')

        except stock_data.DoesNotExist:
            a = stock_data.objects.create(
                item_name=data_get['Varietyname'],
                Quantity=data_get['count'], )
            return render(request, 'old_stock.html')

    return render(request, 'old_stock.html')

@login_required
@csrf_exempt
def add_dealer(request):
    data_get = {key: request.POST[key] for key in request.POST}
    x = database.objects.all()

    if request.method == 'POST':
        try:
            a = database.objects.create(
                                        Subdealer_Name=data_get['bname'],
                                               Address=data_get['add'],
                                               Mobile_No=data_get['mobile'],
                                               E_mail_ID=data_get['email'],
                                               GSTN_Number=data_get['gstn'],
                                               Contact_person_name=data_get['cpname'],
                                               Contact_person_Mobile=data_get['cpphone'],
                                               company=data_get['company'],
                                               IGST=data_get['igst'],
                                               Contact_person_mail_id=data_get['cpemail'],
                                               Brand=data_get['brand'],
                                               Item_name=data_get['itemname'],
                                               hsncode=data_get['hsn'],
                                               tax=data_get['tax'],
                                               Purches_rate=data_get['prate'],
                                               Sale_rate=data_get['srate'],
                                               )
            return redirect('/add_dealer',{'msg':'Data is added...!!!'})
        except stock_data.DoesNotExist:
            return render(request, 'add_dealer.html',{'error':'item is not there '})



    return render(request, 'add_dealer.html',{'x':x})

@login_required()
@csrf_exempt
def delete(request,id):
    x=database.objects.get(id=id)
    x.delete()
    return redirect('view_dealer')

@login_required()
@csrf_exempt
def emp(request):
    x=employee_detaile.objects.all()
    y=len(x)+1
    z=('EMP/00{}'.format(y))
    data_get = {key: request.POST[key] for key in request.POST}
    if request.method=="POST":
        a=employee_detaile.objects.create(
                employee_id=data_get['Employeeid'],
                employee_name=data_get['Name'],
                phone=data_get['Phone'],
                address=data_get['Address'],
                user_id=data_get['Username'],
                password=data_get['Password'],)
        return redirect('/emp')
        # return render(request, 'emp.html',{'z':z})
    return render(request, 'emp.html',{'z':z})

@login_required
@csrf_exempt
def changepaswword(request):
    # u = User.objects.get(username__exact='john')
    # u.set_password('new password')
    # u.save()

    return render(request, 'changepassword.html')

@login_required
@csrf_exempt
def excelpurchase(request):
    x=purchase.objects.all()
    return render(request, 'excelpurchase.html',{'x':x})

@login_required
@csrf_exempt
def excelsales(request):
    x=sale_detaile.objects.all()
    item=[]
    rate=[]
    for i in x:
        item.append(i.prodect)
    for i in item:
        y=database.objects.filter(Item_name__exact=i).get()
        rate.append(y.Sale_rate)

    return render(request, 'excelsales.html',{'x':x,'rate':rate})

@login_required
@csrf_exempt
def new_customer(request):
    data_get = {key: request.POST[key] for key in request.POST}
    if request.method == 'POST':
        a = customer_master.objects.create(customer_name=data_get['Customername'],
                                    Mobile_No=data_get['Mobile'],
                                    GSTN_Number=data_get['GSTN'],
                                    Address=data_get['Address1'],
                                    IGST=data_get['igst'])
        return render(request, 'new_customer.html')


    return render(request, 'new_customer.html')

@login_required
@csrf_exempt
def old_customer(request):
    return render(request, 'old_customer.html')


@login_required
@csrf_exempt
def purchase_data(request):
    y = purchase.objects.all()
    empl=employee_detaile.objects.all()
    z=len(y)+1
    c=datetime.datetime.now()
    b=(c.strftime('%d%m%y/00{}').format(z))
    li=database.objects.all()
    data_get = {key: request.POST[key] for key in request.POST}


    try:
        if request.method == 'POST':
            a = purchase.objects.create(auto_bill_no=data_get['Billno'],
                                        purchase_bill_no=data_get['Purchasebillno'],
                                        company_name=data_get['Companyname'],
                                        invoice_date=data_get['Invoicedate'],
                                        item=data_get['item'],
                                        count=data_get['count1'],
                                        amount=data_get['amount']
                                        )
            sto = stock_data.objects.filter(item_name__exact=a.item).get()
            sto_Q=sto.Quantity
            sto.Quantity=int(sto_Q)+int(a.count)
            sto.save()

        return render(request, 'purchase.html',{'x':today,'bill':b})
    except purchase.DoesNotExist:
        if request.method=='POST':
            a = purchase.objects.create(auto_bill_no=data_get['Billno'],
                                        purchase_bill_no=data_get['Purchasebillno'],
                                        company_name=data_get['Companyname'],
                                        invoice_date=data_get['Invoicedate'],
                                        item=data_get['item'],
                                        count=data_get['count1'],
                                        amount=data_get['amount']
                                        )


            item_name=request.POST['item']
            Quantity=request.POST['count1']
            update=stock_data(item_name=item_name,Quantity=Quantity)
            update.save()


        return render(request, 'purchase.html',{'x':today,'bill':b,'a':li,'emp':empl})



@login_required
@csrf_exempt
def stock(request):
    x=stock_data.objects.all()

    return render(request, 'stock.html',{'x':x})




@login_required
@csrf_exempt
def view_cusomer(request):

    x=customer_master.objects.all()

    return render(request, 'view_customer.html',{'data':x})

@login_required
@csrf_exempt
def view_dealer(request):
    data_html = {key: request.POST[key] for key in request.POST}

    x=database.objects.all()
    stock_count=[]
    try:
        for i in x:
            z=i.Item_name
            # print(z)
            s = stock_data.objects.filter(item_name__exact=z).get()
            t = s.Quantity
            # print(t)
            stock_count.append(t)
        return render(request, 'view_dealer.html', {'x': x,'count':stock_count,})

    except stock_data.DoesNotExist:

        for i in x:
            z=i.Item_name
            if z is not None:
                t='Null'

                stock_count.append(t)

        return render(request, 'view_dealer.html', {'x': x,'count':stock_count,})


@login_required
@csrf_exempt
def view_outstanding(request):

    x=sale_detaile.objects.all()

    return render(request, 'view_outstanding.html',{'x':x})

@login_required
@csrf_exempt
def edit_outstanding(request, id):
    x = sale_detaile.objects.get(id=id)

    return render(request,'edit_outstanding.html', {'x': x})



@login_required
@csrf_exempt
def update_outstanding(request, id):
    a=sale_detaile.objects.all()

    if request.method == 'POST':
        x=sale_detaile.objects.get(id=id)
        x.customer_name=request.POST['companyname']
        x.order_no=request.POST['billno']
        x.payment_date=request.POST['paymentdate']
        x.new_payment=request.POST['payment']
        x.pay_type=request.POST['paymenttype']

        if (x.balance>=x.new_payment):

            x.paid=int(x.paid)+int(x.new_payment)
            x.balance=int(x.total)-int(x.paid)
            x.save()

            bill_no = x.order_no
            date = x.payment_date
            amount = x.new_payment
            paytype = x.pay_type
            # detaile =request.POST['Case']
            y = payment(bill_no=bill_no, date=date, amount=amount, paytype=paytype)
            y.save()
            return redirect('/view_outstanding')

        else:
            return redirect('/view_outstanding')

        # return redirect('/view_outstanding')
    return redirect('/view_outstanding')


@login_required
@csrf_exempt
def view_purchase(request):
    x=purchase.objects.all()
    return render(request, 'view_purchase.html',{'x':x})

@login_required
@csrf_exempt
def view_sales(request):
    x=sale_detaile.objects.all()
    y=purchase.objects.all()
    z=database.objects.all()


    # try:
    #     for i in x:
    #         a1=i.prodect
    #         s1 = database.objects.filter(Item_name__exact=a1).get()
    #         ss1=s1.Sale_rate
    #         print(a1)
    #         s2 = sale_detaile.objects.filter(prodect__exact=a1).get()
    #         ss2=s2.Quantity
    #         # ss3=s2.courier_charge
    #         s=int(ss1)*int(ss2)
    #         print('------------',s)
    #         sss=sale_detaile.objects.get(prodect=a1)
    #         sss.amount=s
    #         sss.save()
    #
    # except database.DoesNotExist:
    #     pass


    return render(request, 'view_sales.html',{'x':x})

@login_required
@csrf_exempt
def viewemp(request):
    x=employee_detaile.objects.all()

    return render(request, 'viewemp.html',{'x':x})


@login_required
@csrf_exempt
def edit_emp(request,id):
    x=employee_detaile.objects.get(id=id)

    return render(request,'edit_emp.html',{'x':x})

@login_required
@csrf_exempt
def update_emp(request,id):
    if request.method == 'POST':
        x=employee_detaile.objects.get(id=id)
        x.employee_id=request.POST['Employeeid']
        x.employee_name=request.POST['Name']
        x.phone=request.POST['Phone']
        x.address=request.POST['Address']
        x.user_id=request.POST['Username']
        x.password=request.POST['Password']
        x.status=request.POST['Status']
        x.save()
        return redirect('/viewemp')
    return redirect('/viewemp')

@login_required
@csrf_exempt
def edit_dealer(request,id):
    x=database.objects.get(id=id)

    return render(request,'edit_dealer.html',{'x':x})

@login_required
@csrf_exempt
def update_dealer(request,id):
    if request.method == 'POST':
        x=database.objects.get(id=id)

        x.Subdealer_Name = request.POST['broker_name']
        x.Address = request.POST['broker_address']
        x.Mobile_No = request.POST['broker_mobile']
        x.GSTN_Number = request.POST['gstnno']
        x.Brand = request.POST['brand']
        x.Item_name = request.POST['broker_variety']
        x.Item_code = request.POST['item_code']
        x.Purches_rate = request.POST['purchaserate']
        x.Sale_rate = request.POST['salesrate']
        x.IGST = request.POST['igst']
        x.save()
        return redirect('/view_dealer')
    return redirect('/view_dealer')

    #     return render(request,'add_dealer.html',{'base_url':BASE_URL})
    # return redirect('add_dealer')

@login_required
@csrf_exempt
def delete_dealer(request,id):
    x=database.objects.get(id=id)
    x.delete()
    return redirect('/view_dealer')


@login_required
@csrf_exempt
def edit_customer(request, id):
    x = customer_master.objects.get(id=id)

    return render(request, 'edit_customer.html', {'x': x,'base_url':BASE_URL})


@login_required
@csrf_exempt
def update_customer(request, id):
    if request.method == 'POST':
        x = customer_master.objects.get(id=id)

        x.customer_name= request.POST['name']
        x.Address = request.POST['address1']
        x.Mobile_No = request.POST['mobile']
        x.GSTN_Number = request.POST['gstn']
        x.IGST = request.POST['igst']
        x.save()
        return redirect('/view_customer')

    return redirect('/view_customer')
#
#
@login_required
@csrf_exempt
def edit_purchase(request, id):
    x = purchase.objects.get(id=id)

    return render(request,'edit_purchase.html', {'x': x,'base_url':BASE_URL})

@login_required
@csrf_exempt
def update_purchase(request, id):
    if request.method == 'POST':
        x = purchase.objects.get(id=id)

        x.auto_bill_no= request.POST['Billno']
        x.purchase_bill_no = request.POST['Purchasebillno']
        x.company_name = request.POST['Companyname']
        x.invoice_date = request.POST['Invoicedate']
        x.item = request.POST['Varietyname']
        x.count = request.POST['Totaltonnage']
        x.amount = request.POST['Price']
        x.save()
        return redirect('/view_purchase')

    return redirect('/view_purchase')


@login_required
@csrf_exempt
def delete_purchase(request,id):
    x=purchase.objects.get(id=id)
    x.delete()
    return redirect('/view_purchase')


@login_required
@csrf_exempt
def edit_stock(request, id):
    x = stock_data.objects.get(id=id)

    return render(request,'edit_stock.html', {'x': x,'base_url':BASE_URL})


@login_required
@csrf_exempt
def update_stock(request, id):
    if request.method == 'POST':
        x = stock_data.objects.get(id=id)

        x.item_name= request.POST['Itemname']
        x.Quantity = request.POST['Quantity']
        x.save()
        return redirect('/stock')

    return redirect('/stock')

@login_required
@csrf_exempt
def print_doc(request,id):
    x=sale_detaile.objects.get(id=id)
    x1=x.amount
    x2=x.Quantity
    x3=int(x1)*int(x2)
    return render(request,'print.html',{'x':x,'total':x3})


@login_required
@csrf_exempt
def payments(request):
    x=payment.objects.all()

    return render(request, 'payments.html',{'x':x})

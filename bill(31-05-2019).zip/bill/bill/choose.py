import datetime

today = datetime.date.today()
# print(today)



IGST = [('active','ACTIVE'),('de-active','DE-ACTIVE')]

mode_of_transport=[('bus','BUS'),
                   ('bike','BIKE'),
                   ('by direct','BY DIRECT'),
                   ('taxi','TAXI'),
                   ('train','TRAIN'),
                   ('air ways','AIR WAYS'),
                   ('courier','COURIER'),
                   ('other','OTHER')
                   ]

pay_type=[('case','CASE'),
          ('cheque','CHEQUE'),
          ('online_transfer','ONLINE_TRANSFER')]
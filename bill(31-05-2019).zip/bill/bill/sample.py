#>>>>>>>>>>>>>>>>>>>>>>>>>> add content detaile for Python<<<<<<<<<<<<<<<<<<<<<<<<<<<<

# def add_dealer(request):
#     data_get = {key: request.POST[key] for key in request.POST}
#     if request.method == 'POST':
#         # try:
#         a = customer_master.objects.create(Subdealer_Name=data_get['bname'],
#                                            Address=data_get['add'],
#                                            Mobile_No=data_get['mobile'],
#                                            E_mail_ID=data_get['email'],
#                                            GSTN_Number=data_get['gstn'],
#                                            Contact_person_name=data_get['cpname'],
#                                            Contact_person_Mobile=data_get['cpphone'],
#                                            IGST=data_get['igst'],
#                                            Contact_person_mail_id=data_get['cpemail'],
#                                            # Brand=data_get['brand'],
#                                            # Item_name=data_get['itemname'],
#                                            # Purches_rate=data_get['prate'],
#                                            # Sale_rate=data_get['srate'],
#                                            )
#         return render(request, 'add_dealer.html')
#     return render(request, 'add_dealer.html')
#
# import datetime
# today = datetime.date.today()
# print (today)

#
# td class="sorting_1">{{ i.order_no }}</td>
#                                             <td>{{ i.customer_name }}</td>
#                                             <td>{{ i.invoice_date }}</td>
#                                             <td>{{ i.place_of_supply }}</td>
#                                             <td>{{ i.mode_of_transport }}</td>
#                                             <td>{{ i.purchase_order_no }}</td>
#                                             <td>{{ i.purchase_order_date }}</td>
#                                             <td>{{}}</td>

#
# a={'name':'midhun','age':23,'tech':'py'}
# x=a['name']
# print(a.keys())
# print(x)


# from selenium import webdriver
# from selenium.webdriver.support.ui import WebDriverWait
# from selenium.webdriver.support import expected_conditions as EC
# from selenium.webdriver.common.keys import Keys
# from selenium.webdriver.common.by import By
# import time
#
# # Replace below path with the absolute path
# # to chromedriver in your computer
# driver = webdriver.Chrome('/home/saket/Downloads/chromedriver')
#
# driver.get("https://web.whatsapp.com/")
# wait = WebDriverWait(driver, 600)
#
# # Replace 'Friend's Name' with the name of your friend
# # or the name of a group
# target = '"Friend\'s Name"'
#
# # Replace the below string with your own message
# string = "Message sent using Python!!!"
#
# x_arg = '//span[contains(@title,' + target + ')]'
# group_title = wait.until(EC.presence_of_element_located((
#     By.XPATH, x_arg)))
# group_title.click()
# inp_xpath = '//div[@class="input"][@dir="auto"][@data-tab="1"]'
# input_box = wait.until(EC.presence_of_element_located((
#     By.XPATH, inp_xpath)))
# for i in range(100):
#     input_box.send_keys(string + Keys.ENTER)
#     time.sleep(1)

# a='abcdefghi'
# b=1,2,3,4,5,6,7,8,9
# for i in b:
#     for j in a:
#         print(i,'.',j)

# def contalpha(n):
#     num = 65
#
#     for i in range(0, n):
#         for j in range(0, i + 1):
#             ch = chr(num)
#             print(ch, end=" ")
#             num = num + 1
#         print("\r")
#     n = 5
#
#
# contalpha(5)

# a='abcdefghi'

# b=1,2,3,4,5,6
# c=len(a)
# d=1
# # for i in a[0:c]:
# #     print(d,'.',i)
# #     e = d = d + 1
# x={'name':'python'}
# for x.keys,x.values in x:
#     print(x.values,x.keys)
# import datetime
# x=datetime.datetime.now()
# print(x.strftime('%d%b'))

# b=len(a)
# print('bill/{}'.format(b))



#
# a=input('Enter the No:')
# n=len(a)
# print(a)
# x=[]
# for i in a:
#     b=int(i)**n
#     x.append(b)
#
# y=sum(x)
# y=str(y)
# print(y)
# if y==a:
#     print('========>ams')
# else:
#     print('========>not ams')
#
# a=int(input('Enter the a value:'))
# b=int(input('Enter the b value:'))
# c=a**2+b**2+2*a*b
# print(c)

#
# a=int(input('Enter the Number   :'))
# for i in range(1,a+1):
#     if (i%)
#-----------------------------------------------------
# a=int(input('Enter the end No   :'))
# for i in range(0,a + 1):
#    if i > 1:
#        for j in range(2,i):
#            if (i % j) == 0:
#                break
#        else:
#            print(i)
#-----------------------------------------------------

#==================================data fetch==========================================
# a=x.item_name
# for i in a:
#     s = stock_data.objects.filter(item_name__exact='mobile').get()
#     t = s.Quantity
#     print(t)


# a=database.objects.values('Item_name')
# b=stock_data.objects.values('item_name')
#
#
# for i in a:
#     g=(i['Item_name'])
#     for j in b:
#         h=(j['item_name'])
#         if g == h:
#             print(i)
#             s = stock_data.objects.filter(item_name__exact=i).get()
#             t = s.Quantity
#             print(t)


# k=stock_data.objects.all().get(item_name=h)
# l=stock_data.objects.filter(item_name=h)
# print(k)
# print(l)

#==================================data fetch==========================================
# from tkinter import *
# import time
#
#
# root = Tk()
# root.title("Clock")
# width = 600
# height = 400
# screen_width = root.winfo_screenwidth()
# screen_height = root.winfo_screenheight()
# x = (screen_width/2)- (width/2)
# y = (screen_height/2) - (height/2)
# root.geometry("%dx%d+%d+%d" % (width, height, x, y))
# root.resizable(0, 0)
# root.config(bg="light blue")
#
#
# #===========================================METHODS=======================================
# def tick():
#     setTime = time.strftime('%I: %M: %S: %p')
#     clock.config(text=setTime )
#     clock.after(200, tick)
#
# #===========================================FRAMES========================================
# Top = Frame(root, width=600, bd=1, relief=SOLID)
# Top.pack(side=TOP)
# Mid = Frame(root, width=600)
# Mid.pack(side=TOP, expand=1)
#
#
# #===========================================LABEL WIDGET==================================
# lbl_title = Label(Top, text="Python: Simple Digital Clock", width=600, font=("arial", 20))
# lbl_title.pack(fill=X)
#
# clock = Label(Mid, font=('times', 50 , 'bold'), fg="green", bg="light blue")
# clock.pack()
#
#
#
# #===========================================INITIALIZATION================================
#
# if __name__ == '__main__':
#     tick()
#     root.mainloop()

#============================================stock fetch from table  =========================
# try:
#     for i in x:
#         z=i.Item_name
#         print(z)
#         # s = stock_data.objects.filter(item_name__exact=z).get()
#         # t = s.Quantity
#         # print(z)
#         return render(request, 'view_dealer.html', {'x': x,})

# except stock_data.DoesNotExist:
#     return render(request, 'view_dealer.html', {'x': x })
# ===========================================================================================
# @login_required
# @csrf_exempt
# def stock(request):
#     x=stock_data.objects.all()
#     y=purchase.objects.all()
#     stock_count=[]
#
#     # for i in x:
#     #     cdata=i.item_name
#     #     for j in  y:
#
#     # for i in x:
#     #     data=i.item_name
#     #     # print(data)
#     #     for j in y:
#     #         if data in j.item:
#     #             # print(data)
#     #             s = purchase.objects.filter(item__exact=data).get()
#     #             t1=s.count
#     #             t2=i.Quantity
#     #             t1 = int(t1)
#     #             t2 = int(t2)
#     #             t=t1+t2
#     #             stock_count.append(t)
#     #             # print(stock_count)
#     #         else:
#     #             t1 = i.Quantity
#     #             print(t1)
#     #             t1 = int(t1)
#     #             stock_count.append(t1)
#
#
#
#     try:
#         for i in x:
#             z=i.item_name
#             print(z)
#             s = purchase.objects.filter(item__exact=z).get()
#             t1=s.count
#             t2=i.Quantity
#             t1 = int(t1)
#             t2 = int(t2)
#             print(t1,'-------t1')
#             print(t2,'-------t2')
#             t=t1+t2
#             stock_count.append(t)
#             # print(stock_count)
#
#         return render(request, 'stock.html', {'x': x,'t':stock_count})
#
#     except purchase.DoesNotExist:
#         for i in x:
#             z=i.item_name
#             # s = purchase.objects.filter(item__exact=z).get()
#             if z not in y:
#                 # t1=0
#                 t2=i.Quantity
#                 # t1=int(t1)
#                 t2=int(t2)
#                 t=t2
#                 stock_count.append(t)
#                 # print(stock_count)
#         return render(request, 'stock.html', {'x': x,'t':stock_count})
#
#     # return render(request, 'stock.html',{'x':x,'t':stock_count})



from datetime import datetime

now = datetime.now()
print(now.strftime('%Y/%m/%d %I:%M:%S'))


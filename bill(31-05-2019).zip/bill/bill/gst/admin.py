from django.contrib import admin
from gst.models import database,purchase,stock_data,sale_detaile,employee_detaile,customer_master,payment

admin.site.register(database)
admin.site.register(purchase)
admin.site.register(stock_data)
admin.site.register(sale_detaile)
admin.site.register(employee_detaile)
admin.site.register(customer_master)
admin.site.register(payment)

from django.apps import AppConfig


class GstConfig(AppConfig):
    name = 'gst'

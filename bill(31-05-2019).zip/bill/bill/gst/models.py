from django.db import models
from choose import *
import datetime


class stock_data(models.Model):
        item_name               =models.CharField(null=False,max_length=80,default='')
        Quantity                =models.CharField(null=False,max_length=8,default='')

class database(models.Model):


    Subdealer_Name          =models.CharField(null=False,max_length=25,default='')
    Address                 =models.CharField(null=False,max_length=100,default='')
    Mobile_No               =models.CharField(null=False,max_length=10,default='')
    E_mail_ID               =models.EmailField(null=False,max_length=30,default='')
    GSTN_Number             =models.CharField(null=False,max_length=25,default='')
    Contact_person_name     =models.CharField(null=False,max_length=30,default='')
    Contact_person_Mobile   =models.CharField(null=False,max_length=10,default='')
    IGST                    =models.CharField(max_length=10, choices=IGST, default='select here')
    Contact_person_mail_id  =models.EmailField(null=False,max_length=30,default='')
    Brand                   =models.CharField(null=False,max_length=25,default='')
    Item_name               =models.CharField(null=False,max_length=25,default='')
    # Item_code               =models.CharField(null=False,max_length=25,default='')
    Purches_rate            =models.CharField(null=False,max_length=8,default='')
    Sale_rate               =models.CharField(null=False,max_length=8,default='')
    # Quantity                =models.ForeignKey(stock_data,on_delete=models.CASCADE)


    def __str__(self):
        return self.Item_name

class customer_master(models.Model):
    customer_name           =models.CharField(null=False,max_length=45,default='')
    Mobile_No               =models.CharField(null=False,max_length=10,default='')
    GSTN_Number             =models.CharField(null=False,max_length=25,default='')
    Address                 =models.CharField(null=False,max_length=100,default='')
    IGST                    =models.CharField(max_length=100, choices=IGST, default='select here')

    def __str__(self):
        return self.customer_name


class purchase(models.Model):
    auto_bill_no            =models.CharField(null=False,max_length=80,default='')
    purchase_bill_no        =models.CharField(null=False,max_length=80,default='')
    company_name            =models.CharField(null=False,max_length=50,default='')
    invoice_date            =models.CharField(null=False,max_length=50,default=today)
    item                    =models.CharField(null=False,max_length=80,default='')
    count                   =models.CharField(null=False,max_length=8,default='')
    amount                  =models.CharField(null=False,max_length=80,default='')


    def __str__(self):
        return self.purchase_bill_no


class sale_detaile(models.Model):
    order_no                =models.CharField(null=True,max_length=25,blank=True,default='')
    customer_name           =models.CharField(null=True,max_length=25,blank=True,default='')
    invoice_date            =models.CharField(null=True,max_length=25,blank=True,default='')
    place_of_supply         =models.CharField(null=True,max_length=25,blank=True,default='')
    mode_of_transport       =models.CharField(max_length=10,choices=mode_of_transport, default='select here')
    purchase_order_no       =models.CharField(null=True,max_length=25,blank=True,default='')
    purchase_order_date     =models.CharField(null=True,max_length=25,blank=True,default='')
    courier_charge          =models.CharField(null=True,max_length=25,blank=True,default='')
    prodect                 =models.CharField(null=True,max_length=25,blank=True,default='')
    amount                  =models.CharField(null=True,max_length=25,blank=True,default='')
    Quantity                =models.CharField(null=True,max_length=25,blank=True,default='')
    time                    =models.CharField(max_length=300,default='')
    total                   =models.CharField(max_length=100,default='')
    balance                 =models.CharField(max_length=100,default='')
    paid                    =models.CharField(max_length=100,default='')
    payment_date            =models.CharField(max_length=100,default='')
    new_payment             =models.CharField(max_length=100,default='')
    pay_type                =models.CharField(max_length=100,choices=pay_type,default='select here')

    def __str__(self):
        return self.customer_name


class employee_detaile(models.Model):
    employee_id             =models.CharField(null=False,max_length=80,default='')
    employee_name           =models.CharField(null=False,max_length=80,default='')
    phone                   =models.CharField(null=False,max_length=10,default='')
    address                 =models.CharField(null=False,max_length=50,default='')
    user_id                 =models.CharField(null=False,max_length=25,default='')
    password                =models.CharField(null=False,max_length=15,default='')

    def __str__(self):
        return self.employee_name

class payment(models.Model):
    bill_no                 =models.CharField(null=True,max_length=25,blank=True,default='')
    date                    =models.CharField(null=True,max_length=25,blank=True,default='')
    amount                  =models.CharField(null=True,max_length=25,blank=True,default='')
    paytype                 =models.CharField(null=True,max_length=25,blank=True,default='')
    detaile                 =models.CharField(null=True,max_length=25,blank=True,default='')
    bank                    =models.CharField(null=True,max_length=25,blank=True,default='')
    branch                  =models.CharField(null=True,max_length=25,blank=True,default='')
    cheque_no               =models.CharField(null=True,max_length=25,blank=True,default='')
    cheque_date             =models.CharField(null=True,max_length=25,blank=True,default='')
    transfer_no             =models.CharField(null=True,max_length=25,blank=True,default='')
    transfer_method         =models.CharField(null=True,max_length=25,blank=True,default='')


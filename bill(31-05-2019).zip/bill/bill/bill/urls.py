
from django.contrib import admin
from django.urls import path,include
from django.views.generic.base import TemplateView
from gst.views import *
from django.conf.urls import url
from django.conf.urls.static import static
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from bill import settings
from bill.settings import *


urlpatterns = [
    path('admin/', admin.site.urls),
    # path('accounts/', include('django.contrib.auth.urls')),
    # path('', TemplateView.as_view(template_name='index.html'), name='home'),


    url(r'^dashboard', dash_board),
    url(r'^dash_board', dash_board),
    url(r'^add_dealer', add_dealer),
    url(r'^view_dealer',view_dealer),
    url(r'^new_customer',new_customer),
    url(r'^index', index),
    url(r'^$', index),
    url(r'^logout', signout),
    url(r'^delete/(?P<id>\d+)$/',delete),
    url(r'^add',add),
    url(r'^emp',emp),
    url(r'^changepassword',changepaswword),
    url(r'^excelpurchase',excelpurchase),
    url(r'^excelsales',excelsales),
    url(r'^old_customer',old_customer),
    url(r'^old_stock',old_stock),
    url(r'^payments',payments),
    url(r'^purchase',purchase_data),
    url(r'^stock',stock),
    url(r'^view_customer',view_cusomer),
    url(r'^view_outstanding',view_outstanding),
    url(r'^view_purchase',view_purchase),
    url(r'^view_sales',view_sales),
    url(r'^viewemp',viewemp),
    url(r'^edit_dealer/(?P<id>\d+)$',edit_dealer),
    url(r'^update_dealer/(?P<id>\d+)$',update_dealer),
    url(r'^delete_dealer/(?P<id>\d+)$',delete_dealer),
    url(r'^edit_customer/(?P<id>\d+)$',edit_customer),
    url(r'^update_customer/(?P<id>\d+)$',update_customer),
    url(r'^edit_purchase/(?P<id>\d+)$',edit_purchase),
    url(r'^update_purchase/(?P<id>\d+)$',update_purchase),
    url(r'^delete_purchase/(?P<id>\d+)$', delete_purchase),
    url(r'^edit_stock/(?P<id>\d+)$',edit_stock),
    url(r'^update_stock/(?P<id>\d+)$', update_stock),
    url(r'^edit_sales/(?P<id>\d+)$',editsales),
    url(r'^update_sales/(?P<id>\d+)$', update_sales),
    url(r'^delete_sales/(?P<id>\d+)$', delete_sales),
    url(r'^print/(?P<id>\d+)$',print),
    url(r'^edit_outstanding/(?P<id>\d+)$',edit_outstanding),
    url(r'^update_outstanding/(?P<id>\d+)$', update_outstanding),


] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
urlpatterns += staticfiles_urlpatterns()





